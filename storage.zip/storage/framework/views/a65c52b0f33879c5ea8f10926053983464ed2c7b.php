<?php $__env->startSection('content'); ?>

<template>
<v-app id="inspire">
    <div id="login">
    <v-content>
        <v-container fluid fill-height>
            <v-layout align-center justify-center style="margin-top: 200px;">
                <v-flex xs12 sm8 md4>
                <v-flex xs12 sm12>
                    
                    <img src="<?php echo e(asset('storage/logo1.jpg')); ?>" alt="SpeedBall"  style="width: 150px; height: 150px; margin-top: -150px;
                    margin-left: 150px;">
                    </v-flex>
                    <v-card class="elevation-12">
                        <v-toolbar dark color="primary">
                            <v-toolbar-title>Login form</v-toolbar-title>
                            <v-spacer></v-spacer>
                            
                        </v-toolbar>
                        <v-form method="POST" action="<?php echo e(route('login')); ?>">
                            <v-card-text>
                                    <?php echo csrf_field(); ?>
                                    <v-text-field prepend-icon="person" name="email" label="Login" type="text"></v-text-field>
                                    <?php if($errors->has('email')): ?>
                                    <p style="color: red;"><?php echo e($errors->first('email')); ?></p>
                                    
                                    <?php endif; ?>
                                    <v-divider></v-divider>
                                    <v-text-field id="password" prepend-icon="lock" name="password" label="Password" type="password"></v-text-field>

                                    <?php if($errors->has('password')): ?>
                                    
                                    <p style="color: red;"><?php echo e($errors->first('password')); ?></p>
                                    <?php endif; ?>

                                    <div class="form-group row">
                                        <div class="col-md-6 offset-md-4">
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Remember Me')); ?>

                                                </label>
                                            </div>
                                        </div>
                                    </div>

                            </v-card-text>
                            <v-card-actions>
                                <div class="form-group row mb-0">
                                    <div class="col-md-8 offset-md-4">
                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Your Password?')); ?>

                                        </a>
                                    </div>
                                </div>
                                <v-spacer></v-spacer>
                                <v-btn color="primary" type="submit">Login</v-btn>
                            </v-card-actions>
                        </v-form>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
    </v-content>
</div>
</v-app>
</template>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>