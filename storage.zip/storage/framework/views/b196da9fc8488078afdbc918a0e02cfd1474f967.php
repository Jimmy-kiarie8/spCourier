<?php $__env->startSection('title'); ?>
Courier
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<my-header :user="<?php echo e(Auth::user()); ?>" :role="<?php echo e(json_encode($rolename)); ?>"></my-header>
<transition name="fade">
<router-view :user="<?php echo e(Auth::user()); ?>" :role="<?php echo e(json_encode($rolename)); ?>"></router-view>
</transition>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>