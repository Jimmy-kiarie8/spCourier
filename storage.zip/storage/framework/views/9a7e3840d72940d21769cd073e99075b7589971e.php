<?php $__env->startSection('content'); ?>
<head-view :user="<?php echo e(Auth::user()); ?>"></head-view>
<a class="btn btn-primary" href="http://courier.dev/courier#/">Back</a>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Import Excel File</div>

                <div class="card-body">
                    <form action="<?php echo e(route("import")); ?>" method="post" enctype="multipart/form-data">
                       <?php echo e(csrf_field()); ?>

                      <div class="form-group">
                          <input type="file" name="shipment" class="btn btn-default"/>
                      </div><br>
                      <div class="form-group">
                          <button class="btn btn-primary" type="submit">Import</button>
                          
                      </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>