<?php

namespace App;

class Sms
{
    
}
