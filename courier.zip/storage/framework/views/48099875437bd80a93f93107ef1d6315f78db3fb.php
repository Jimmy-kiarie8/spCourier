<?php $__env->startComponent('mail::message'); ?>



<?php $__env->startComponent('mail::panel'); ?>
The following shipments are schedueled today and tomorrow
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => url('/courier#/scheduled')]); ?>
See Shipments
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::table'); ?>
| Waybill        | Client Name        | Phone         | Email  | delivery Date 	 |
| ------------------ |:-------------:| ---------:|:---------:|
<?php $__currentLoopData = $shipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
| <?php echo e($value->bar_code); ?>   | <?php echo e($value->client_name); ?>   | <?php echo e($value->client_phone); ?> | <?php echo e($value->client_email); ?> | <?php echo e($value->derivery_date); ?> |
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->renderComponent(); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
