<?php $__env->startSection('content'); ?>
<v-card>
    <li class="list-group-item active">Shipment Details</li>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Waybill Number</th>
                <th scope="col">From</th>
                <th scope="col">To</th>
                <th scope="col">Percels Sent</th>
                <th scope="col">Derivery Date</th>
                <th scope="col">Derivery Time</th>
                <th scope="col">Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope><?php echo e($shipments->bar_code); ?></th>
                <td><?php echo e($shipments->from_city); ?></td>
                <td><?php echo e($shipments->to_city); ?></td>
                <td><?php echo e($shipments->amount_ordered); ?></td>
                <td><?php echo e($shipments->derivery_date); ?></td>
                <td><?php echo e($shipments->derivery_time); ?></td>
                <td><?php echo e($shipments->status); ?></td>
            </tr>
        </tbody>
      </table>
      <li class="list-group-item active">Derivery Details</li>
    <table class="table">
            <thead>
                <tr>
                    <th scope="col">Received By</th>
                    <th scope="col">Id Number</th>
                    <th scope="col">Email Number</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Date Received</th>
                    <th scope="col">Time Received</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope><?php echo e($shipments->client_name); ?></th>
                    <td>'12343'</td>
                    <td><?php echo e($shipments->client_email); ?></td>
                    <td><?php echo e($shipments->client_phone); ?></td>
                    <td><?php echo e($shipments->derivery_date); ?></td>
                    <td><?php echo e($shipments->derivery_time); ?></td>
                </tr>
            </tbody>
          </table>
          <li class="list-group-item active">Sender Details</li>
          <table class="table">
                  <thead>
                      <tr>
                          <th scope="col">Sent By</th>
                          <th scope="col">Id Number</th>
                          <th scope="col">Email Number</th>
                          <th scope="col">Phone Number</th>
                      </tr>
                  </thead>
                  <tbody>
                      <tr>
                          <th><?php echo e($shipments->sender_name); ?></th>
                          <td>12343</td>
                          <td><?php echo e($shipments->sender_email); ?></td>
                          <td><?php echo e($shipments->sender_phone); ?></td>
                      </tr>
                  </tbody>
                </table>
          <li class="list-group-item active">Products Details</li>
          <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Events</th>
                        <th scope="col">Event date and time</th>
                        <th scope="col">Location</th>
                        <th scope="col">Remark</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $shipments->statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $statuses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(($key)+1); ?></th>
                        <td><?php echo e($statuses->status); ?></td>
                        <td><?php echo e($statuses->created_at); ?></td>
                        <td><?php echo e($statuses->location); ?></td>
                        <td><?php echo e($statuses->remark); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
</v-card>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>