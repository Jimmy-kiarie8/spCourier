					</td>
				</tr>
			</table>

		</td>
	</tr>
</table>
<img border="0" src="<?php echo e(Request::getSchemeAndHttpHost()); ?>/vendor/beautymail/assets/images/widgets/spacer.gif" width="1" height="15" class="divider"><br>