<?php

use Faker\Generator as Faker;

$factory->define(App\Charge::class, function (Faker $faker) {
    return [
        //
    ];
});
