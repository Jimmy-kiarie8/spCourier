<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class row_users extends Model
{
	protected $table = 'row_users';
}
